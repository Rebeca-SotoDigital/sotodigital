# Soto Digital — Brevo: lista 6 / ORIGEN=4 (WhatsApp)

## Objetivo
Sincronizar leads **confirmados** desde el almacenamiento privado de Arsys con Brevo, lista **6**, atributo de categoría **ORIGEN=4**, y notificar al correo **ai@soto-digital.com**. **No se ha desplegado automáticamente**.

## Archivos
- `whatsapp/brevo-client.php`: llamadas a la API de Brevo y aviso interno por email.
- `whatsapp/lead-notifier.php`: selecciona leads, evita procesar repetidos y mantiene estados de revisión.
- `whatsapp/run-lead-notifier.php`: entrada HTTPS de ejecución manual/autenticada.

## Configuración privada en ARSYS (NO GitHub)
Añadir al array ya existente `whatsapp/whatsapp-config.php`:

```php
'brevo_api_key' => 'CLAVE_PRIVADA_EXISTENTE',
'brevo_list_id' => 6,
'brevo_sender_email' => 'REMITENTE_VERIFICADO_EN_BREVO',
'lead_notification_email' => 'ai@soto-digital.com',
'brevo_start_at' => '2026-11-28T00:00:00+01:00', // EJEMPLO; sustituir por fecha de activación acordada
'brevo_enabled' => false,
```

El inicio debe fijarse explícitamente en la fecha efectiva que se desee. Así no se sincroniza automáticamente el lead de prueba anterior. No usar la fecha ilustrativa sin revisarla.

## Instalación
1. Copiar estos tres PHP a `html/whatsapp/` en la rama de trabajo y luego desplegar después de probar, sin modificar claves del repositorio.
2. En `whatsapp/.htaccess`, actualizar la expresión de la regla que permite solo puntos de entrada: añadir `run-lead-notifier` al conjunto permitido. Sin ello Apache debe responder 403 y el ejecutor no funcionará. Mantener el bloqueo de los demás PHP.
3. Verificar que la carpeta privada `data/soto-whatsapp-data/` existe y es escribible; el notificatorio crea `notifications/`.
4. Confirmar que el email de remitente está autorizado por Brevo y que el valor 4 sigue correspondiendo a WhatsApp en ORIGEN.
5. Mantener `brevo_enabled=false` durante la instalación. Probar autenticación de la URL; una llamada POST con el token `X-Soto-Worker-Token` debería devolver `BREVO_DISABLED` (503).
6. **Solo después**, habilitar `brevo_enabled=true` y ejecutar el notificador manualmente desde un programador HTTPS mediante POST y la cabecera secreta, para un lead de prueba nuevo.

## Seguridad y avisos
- No subir `whatsapp-config.php` ni la clave API al repositorio, ni poner secretos en URLs.
- El email se envía al equipo, **no al cliente**, ni se envía propuesta comercial automáticamente.
- El trabajo de Brevo está desacoplado del de WhatsApp: si falla Brevo, el JSON continúa en Arsys.
- El notificador conserva estados `contacto_revision` y `email_revision` sin reintentos automáticos; revisar de forma manual en Brevo antes de rearmar. En caso de un corte durante el envío, no se puede descartar que Brevo haya aceptado el email.
- La versión actual **todavía no captura un teléfono de contacto alternativo ni lo confirma**. Si no consta ese dato, el aviso interno lo indicará como pendiente. Eso se añadirá en el siguiente cambio del flujo de leads.
- `ORIGEN` se actualiza al valor 4 al sincronizar: si una dirección ya existía procedente de la web, su origen pasará a indicar el último canal, WhatsApp.
